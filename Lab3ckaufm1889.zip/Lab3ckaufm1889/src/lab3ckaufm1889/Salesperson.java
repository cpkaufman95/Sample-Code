/*
*Programmer: Connor Kaufman
* classID: ckaufm1889
* CIS 2600: Business Application Programming
* Fall 2016
* Due date: 11/14/16
* Date completed: 11/15/16
**************************************
* Program Explanation
* This program uses a array of objects and a scanner class to take 20
* salesperson names and thier ids sorting them in ascending order with thier
* annual sales.
**************************************/

/**Name of the program*/
package lab3ckaufm1889;

/**Public is the access specifier that makes everything in the program
*able to be used by any one looking at the code. class identifies
*Salesperson as a class. This line is also known as the class header.
*everything between the curly braces is the class body.*/
public class Salesperson {
    
/**private makes it so it is only able to be referenced from this class.
* int, and double are primitive types while String is a class. Salesperson,
* salesAmount and employeeId are all variables.*/
    private String salesperson = "";
    private int employeeId = 0;
    private double salesAmount = 0.0;
    
/**This is a constructor that identifies the 3 variables and allows them to be 
 * referenced in the main class.*/    
    Salesperson(String person, int Id, double sales)
    {
           salesperson = person;
           employeeId = Id;
           salesAmount = sales;
    }
    
/**This is a getter and setter that sets the salesperson to the salesperson
 * entered in the main class and the getter gets the person when called in the
 * main class. Then returns the salesperson.*/
    public void setPerson(String salesperson)
   {   
      this.salesperson = salesperson;
   }   
    public String getPerson()
   {
       return salesperson;
   }
    
/**This is also a getter and setter that sets the employeeId to the employeeId
 * entered in the main class and the getter gets the number when called in the
 * main class. Then returns the employeeId.*/
    public void setEmpId(int employeeId)
   {
       this.employeeId = employeeId;
   }   
    public int getEmpId()
   {
       return employeeId;
   }
    
/**This is also a getter and setter that sets the salesAmount to the salesAmount
 * entered in the main class and the getter gets the number when called in the
 * main class. Then returns the sales amount.*/
    public void setSales(double salesAmount)
   {
       this.salesAmount = salesAmount;
   }   
    public double getSales()
   {
       return salesAmount;
   }
}
