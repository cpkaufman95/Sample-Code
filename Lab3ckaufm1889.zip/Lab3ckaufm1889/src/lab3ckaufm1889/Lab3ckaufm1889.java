/*
*Programmer: Connor Kaufman
* classID: ckaufm1889
* CIS 2600: Business Application Programming
* Fall 2016
* Due date: 11/14/16
* Date completed: 11/15/16
**************************************
* Program Explanation
* This program uses a array of objects and a scanner class to take 20
* salesperson names and thier ids sorting them in ascending order with thier
* annual sales.
**************************************/

/**Name of the program.*/
package lab3ckaufm1889;

/**Allows use of array of objects. The one below it allows use of the scanner
 * class.*/
import java.util.*;
import java.util.Scanner;

/**Public is the access specifier that makes everything in the program
*able to be used by any one looking at the code. class identifies
*Lab3ckaufm1889 as a class. This line is also known as the class header.
*everything between the curly braces is the class body.*/
public class Lab3ckaufm1889 {

/**The line is a method. static means that the method works without
*instantiating an object of the class. void is the methods return type.
*between the curly braces is the method body. string is a class.
*the square brackets indicate an array. args identifies the array.*/    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {

/**This is an array of objects Salesperson creates the array of objects and 
 * acts as a constructor. classInfo is the name of he array and new Salesperson
 [20] sets the limit of spaces in the array to 20.*/        
        Salesperson[] classInfo = new Salesperson [20];
        
/**String is a class and the string is declared as salesperson and choice and 
* initialized. int, double are primitive types and int is declared as 
* employeeId and count. double is declared as salesAmount.*/       
        String salesperson = "";
        int employeeId = 0;
        double salesAmount = 0.0;
        int count = 0;
        String choice = "";
        
/**Scanner inputDevice allows us to input data into the program
*when we run it*/         
        Scanner inputDevice = new Scanner(System.in);
        
/**System is a class. out shows that this line will produce an output.
*println ensures that what is written inside the parentheses appears in
*the output and also makes it so it moves to the next line after it
*outputs. The name of the company is output and ascii is also there for display*/        
        System.out.println("===============================");
        System.out.println("        Wood Warriors");
        
        
/**This is a while loop. a while loop will continue to loop as long as the 
 * input inside the parentheses holds true. this while loop tests as long as 
 * the choice entered is not equal to Q then it will keep going with the rest
 * of the loop.*/        
   while(!choice.equals ("Q"))
   {   
/**outputs ascii and asks the user for input of specified characters. 
 * choice refers to the choice variable and inputDevice references the 
 * scanner and moves to the next line*/       
       System.out.println("===============================");
       System.out.println("Would you like to (A)dd, (D)elete, (C)hange, or (Q)uit?");
       choice = inputDevice.nextLine();
       
/**This is a switch case which takes the choice entered and compares it to 
 * the cases below to see if it matches any of the specified characters.*/        
       switch (choice)
    {
/**This case references choice A which allows the user to add a salesperson.
 * the count references the amount of people already in the array and then
 * it calls the add method and includes the array name and int count.
 * The other cases D, C, Q, and default. D calls the delete method which allows
 * the user to remove a record from the array. C calls the change method
 * which allows the user to change the sales of someone in the array. Q
 * ends the program, and default only executes when a choice that is entered
 * is not valid. */          
        case "A":
            count = add(classInfo, count);
            break;
        case "D":
            count = delete(classInfo, count);
            break;
        case "C":
            change(classInfo, count);
            break;
        case "Q":
            System.out.println("Thanks for running the program!");
            break;
        default:
            System.out.println("Please enter a valid character");
            
    }
   }        
   
    }
    
/**This is the add method which includes the array and current count.
 * int is the return type.*/    
    public static int add(Salesperson[] classInfo, int count)
    {
/**Enables use of the scanner in the method*/        
       Scanner inputDevice = new Scanner(System.in);
       
/**Declared and initialized variables employeeId, salesperson, and salesAmount*/       
       int employeeId = 0;
       String salesperson = "";
       double salesAmount = 0.0;

/**This is a if else statement it tests that if count equals the maximum length
 * of the array then it will output that you cannot enter anymore people*/       
       if(count == classInfo.length)
            {
                System.out.println("Maximum people entered cannot enter anymore");
            }
       
/**The else will execute when there is still room in the array to add a person
 * it will prompt for employee id to be entered by the user. Also ascii is 
 * there for display.*/       
            else
            {
                System.out.println("===============================");
                System.out.print("Enter Employee ID: ");
                employeeId = inputDevice.nextInt();
 
/**This is a for loop it declares the int c and initializes it as 0 and then
 * tests c less than count and then adds to the count. The if statement 
 * tests if the employee id that was entered is already in the array or not.
 * if it is already in the array then the if statement will output the line
 * saying that the id already exists and prompt to enter the employee ID again.*/
            for(int c = 0; c < count; ++c)
           {         
       if(classInfo[c].getEmpId() == employeeId)
       {   
          System.out.print("ID already exists enter a different number, ");
          System.out.print("Enter Employee ID: ");
          employeeId = inputDevice.nextInt();
       }
           }
            
/**Prompts for the salesperson name and puts it on the next line.
 * Prompts for the sales amount of the salesperson and moves to the next line*/
       System.out.print("Enter salesperson name: ");
       inputDevice.nextLine();
       salesperson = inputDevice.nextLine();
       System.out.print("Enter sales amount: ");
       salesAmount = inputDevice.nextDouble();
         
/**Uses the array and its count to set the new constructor for the salesperson,
 * employeeId, and salesAmount*/               
       classInfo [count] = new Salesperson(salesperson, employeeId, salesAmount);

/**++count adds to the count of the array and then display calls the display
 * method referencing the array name and count.*/       
       ++count;
       display(classInfo, count);
            }
       
/**Returns count to the main method*/            
       return count; 
    }
    
/**This is the delete method which allows the user to remove a record from
 * the array and reduce the count.*/    
    public static int delete(Salesperson[] classInfo, int count)
    {
        
/**Enables use of the scanner for input by the user.*/        
        Scanner inputDevice = new Scanner(System.in);
        
/**Declared and initialized variables salesAmount, salesperson, employeeId, and
 * position.*/        
        double salesAmount = 0.0;
        String salesperson = "";
        int employeeId = 0;
        int position = 0;
        
/**This if statement test that if the count equals 0 then it will output that
 * there is nothing to delete and will then prompt for Add delete change or quit.*/        
        if(count == 0)
        {
            
            System.out.println("Nothing to delete please enter a different command ");  
            
        }
        
/**else statement executes if the count is not equal to zero and prompts for 
 * the Id to remove and then puts it on the next line.*/
        else 
        {    
            System.out.print("Enter ID to remove: ");
            employeeId = inputDevice.nextInt();
            
/**For loop that sets c to 0 and then executes when c is less than count.*/
            for(int c = 0; c < count; ++c)
            { 
      
/**If statement that takes the position in the array and gets the empId from
 * the Salesperson class and equals the employee id.*/
            if(classInfo[c].getEmpId() == employeeId)
            {
                
/**Sets position to c.*/
             position = c;
            }
             
            }
            
/**For loop that sets c to position of the array and then decreases the count
 * of the array for the position of the id that was entered above.*/
            for(int c = position; c < count -1; ++c)
            {
                classInfo[c] = classInfo[c + 1];
            }
            
/**Decreases the count of the array and then displays the new output via the 
 * display method.*/
            --count;
            display(classInfo, count);
        }
       
/**Returns count to the main method*/        
        return count;
    }

/**This is the change method that allows the user to change the sales amount of
 * a salesperson in the array.*/    
    public static void change(Salesperson[] classInfo, int count)
    {
        
/**Enables use of the scanner for input by the user.*/        
        Scanner inputDevice = new Scanner(System.in);
        
/**Declared and initialized variables salesAmount, employeeId,
 * position, and change which has a boolean primitive type and it is initialized
 * to false.*/        
        int employeeId = 0;
        double salesAmount = 0.0;
        int position = 0;
        boolean change = false;
        
/**This if statement test that if the count equals 0 then it will output that
 * there is nothing to change and will then prompt for Add delete change or quit.*/        
        if(count == 0)
        {
            System.out.println("Nothing to change please enter a different command ");  
        }
        
/**else statement executes if the count is not equal to zero and prompts for 
 * the Id to change and then puts it on the next line.*/        
        else 
        {
            System.out.print("Enter ID to change: ");
            employeeId = inputDevice.nextInt();

/**For loop that sets c to 0 and then executes when c is less than count.*/
            for(int c = position; c < count; ++c)
            {
                
/**If statement that takes the position in the array and gets the empId from
 * the Salesperson class and equals the employee id.*/
            if(classInfo[c].getEmpId() == employeeId)
            {
                
/**Sets position to c.*/
            position = c;
            
/**Prompts for the new sales and then sets it for the position in the array that
 * was specified by the id that was entered above.*/
            System.out.print("New Annual Sales: ");  
            salesAmount = inputDevice.nextDouble();
            classInfo[position].setSales(salesAmount);
            
/**This makes it so that the change is set to true.*/
            change = true;
            }
            }
            
/**This if statement tests that if the change is not true then it will display
 * that the id number cannot be found because it does not exist in the array.*/
            if(!change)
            {
                System.out.println("Id number cannot be found");
            }
            
/**Calls the display method and displays the new sales for the id of the 
 employee that is entered.*/
            display(classInfo, count); 
        } 
    }
    /**This is the display method. public identifies it so that anyone has access
     * to it static is its identifier and void is the return type which since
     * it is void it means there is no return type. Salesperson serves as a
     * constructor and the calls the array and the count integer. The method 
     * then takes all the information entered above and displays it through the
     * bubble sort and the print statements.*/
    public static void display(Salesperson[] classInfo, int count)
    {  
        
   /**This is a bubble sort Salesperson is identified as a temp. int is 
    * identified as a and b so that the bubble sort can compare the previously 
    * entered ID and test it against the new ID that was entered and it will 
    * then take the smaller of the two and display them in ascending order 
    * in the output. int highsub is used to substitute count -1. The two for 
    * loops are used to test the two ID numbers against each other. The if 
    * statement uses the arrays position b to grab the EmpId from the Salesperson 
    * class and test if the one entered is greater than the previous numbers if 
    * it is greater than it will move it below the numbers that were previously 
    * entered. The contents of the if statement makes the temp declared as the 
    * array and position of int b. Then the array at position b is declared as 
    * the array and position b plus 1. finally it takes the array and b plus 1
    * and declared it as the temp. This concludes the bubble sort.*/
   Salesperson temp;
      int a, b;
      int highsub = count - 1;
        for(a = 0; a < highsub; ++a)
         for(b = 0; b < highsub; ++b)
           if(classInfo[b].getEmpId() > classInfo[b + 1].getEmpId()) 
           {
               temp = classInfo[b];
               classInfo[b] = classInfo[b + 1];
               classInfo[b + 1] = temp;
           }
        
        /**The following statements print out ascii and then moves on to the 
         * next line. which is a for loop referencing the int a that is declared
         * above in the bubble sort. The last set of statements print the ID, 
         * Salesperson, and Annual Sales it takes the array position and uses 
         * getEmpId to get the Id from the Salesperson class also uses 
         * getPerson and getSales to grab the inputed items from the Salesperson
         * class.*/
        System.out.println("===============================");
        for(a = 0; a < count; ++a)
        {
        System.out.printf("ID: " + classInfo[a].getEmpId());
        System.out.printf("  Salesperson: " + classInfo[a].getPerson());
        System.out.printf("  Annual Sales: $" + classInfo[a].getSales() + "\n");
        }
    }   
}
